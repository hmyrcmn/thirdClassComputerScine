select kt.ISBN, kt.kitapAdi as "Kitabın Adı",
concat_ws(' ', y.yazarAdi, y.yazarSoyadi) as "Yazar Ad Soyad",
"Alınmadı" as "Kitabın Durumu"
from ((kitaplar as kt left join kayitlar as k on kt.ISBN=k.ISBN) inner join yazarlar as y on kt.yazarID=y.yazarID)
where aTarih is null