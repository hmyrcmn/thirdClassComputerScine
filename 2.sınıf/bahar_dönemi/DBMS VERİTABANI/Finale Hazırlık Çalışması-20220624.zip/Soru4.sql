select kt.ISBN, kt.kitapAdi as "Kitap Adı", concat_ws(' ', y.yazarAdi, y.yazarSoyadi) as "Yazarı",
concat_ws(' ', u.uyeAdi, u.uyeSoyadi) as "Üye Ad Soyad", datediff(k.vTarih,k.aTarih) as "Süresi"
from ((kayitlar as k inner join uyeler as u on k.uyeID=u.uyeID) inner join (kitaplar as kt inner join yazarlar as y on kt.yazarID=y.yazarID) on k.ISBN=kt.ISBN)
where k.vTarih is not NULL
order by ISBN