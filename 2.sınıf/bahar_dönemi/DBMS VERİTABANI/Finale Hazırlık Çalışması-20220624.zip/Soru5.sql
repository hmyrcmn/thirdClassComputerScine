select k.uyeID as "Üye ID", concat_ws(' ',u.uyeAdi, u.uyeSoyadi) as "Üye",
Count(k.uyeID) as "Alınan Kitap Sayısı",
(Count(k.aTarih)-Count(k.vTarih)) as "İade edilmeyen Kitap Sayısı"
FROM kayitlar as k LEFT JOIN uyeler as u on k.uyeID=u.uyeID
GROUP BY k.uyeID
HAVING Count(k.uyeID)>1