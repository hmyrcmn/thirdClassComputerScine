<?php


$website = "BTU.EDU.TR";
echo "ayarlar tanımlandı!";

?>