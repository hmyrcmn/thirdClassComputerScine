<?php
include_once "config2.php";
// require "config.php";
?>

<html>
<body>

<h2>Title</h2>
<hr>


<?php
include_once "config.php";
?>



<?php
    // $n1 = 3;
    // echo "İşlemin sonucu: ". ( ($n1*2)/3 ) ." dir.";


    for($i=3; $i<=5; $i+=1)
    {
        echo $i."<br>\n";
    }

    $j = 3;
    while($j <= 5)
    {
        echo $j."<br>\n";

        $j++;
    }

    echo "<hr>";
?>

<br>
<br>
<br>

<?php
    $b = true;
    echo "İ: ".$i."<br>\n";
    echo "J: ".$j."<br>\n";
    if ($j > 3 || $b)
    {
        echo "J 3'ten büyüktür.";
    }

    $j = 1;
    switch ($j)
    {
        case 1:
            echo "j 1dir";
            // break;
        case 2:
            echo "j 2dir";
            break;
        default:
            echo "j başka bişe";
    }

    echo $website;
?>

</body>
</html>