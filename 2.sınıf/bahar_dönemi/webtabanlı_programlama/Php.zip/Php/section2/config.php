<?php 

$website = "BTU.EDU.TR";
echo "TEST";

?>