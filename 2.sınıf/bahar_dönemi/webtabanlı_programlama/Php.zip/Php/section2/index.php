<?php
// error_reporting(E_ALL);
include_once "config.php";
?>
<html>

<body>

<b>hello</b> world

<?php
include_once "config.php";
?>

<hr>

<?php

$i = 3;

echo "İşlemin sonucu:" . (($i * 5)+12)/8 . "<br>\n";

$b = true;
if($b || $i == 3)
{
    echo "ifade doğru";
}
else
{
    echo "ifade yanlış";
}

echo "<hr>";

for($j=6; $j <= 12 ; $j++)
{
    echo $j."<br>\n"; 
}


$k = 6;
while($k <= 12)
{
    echo $k."<br>\n";

    $k++;
}


echo $website;
?>

</body>
</html>
